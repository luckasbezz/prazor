import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://daacbclycxwsjeyipavm.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6Ikp...'; // truncado
export const supabase = createClient(supabaseUrl, supabaseKey);