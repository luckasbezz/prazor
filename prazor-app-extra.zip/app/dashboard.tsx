
import Header from './components/Header'

export default function Dashboard() {
  return (
    <>
      <Header />
      <div style={{ padding: '2rem' }}>
        <h2>Dashboard</h2>
        <p>Lista de produtos com vencimentos em breve.</p>
      </div>
    </>
  )
}
