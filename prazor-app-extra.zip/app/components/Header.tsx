
export default function Header() {
  return (
    <header style={{ padding: "1rem", background: "#eee", marginBottom: "2rem" }}>
      <h1>Prazor</h1>
    </header>
  );
}
